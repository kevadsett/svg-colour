var UserInput = {
	initialise: function() {
		$('.svg-component').click(function(event) {
			appEvents.emit('fill', event.target);
		})

		$('.reset-button').click(function(event) {
			appEvents.emit('reset');
		});

		$('.colour-swatch').click(function(event) {
			appEvents.emit('colourPressed', $(event.target).index())
		});
	}
}